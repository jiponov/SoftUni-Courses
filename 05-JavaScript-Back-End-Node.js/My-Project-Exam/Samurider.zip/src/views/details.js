import { html } from '../lib.js';
import { getMotoById, deleteById } from '../api/data.js';
import { getUserData } from '../util.js';

const detailsTemplate = (moto, isOwner, onDelete) => html`
<section id="details">
    <div id="details-wrapper">
        <img id="details-img" src="${moto.imageUrl}" alt="example1" />
        <p id="details-title">${moto.model}</p>
        <div id="info-wrapper">
            <div id="details-description">
                <p class="year">Year: ${moto.year}</p>
                <p class="mileage">Mileage: ${moto.mileage}</p>
                <p class="contact">Contact Number: ${moto.contact}</p>
                <p id="motorcycle-description">${moto.about}</p>
            </div>
            <!--Edit and Delete are only for creator-->
            ${isOwner ?
            html`<div id="action-buttons">
                <a href="/edit/${moto._id}" id="edit-btn">Edit</a>
                <a @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a>
            </div>`
            : null}
        </div>
    </div>
</section>`;


export async function detailsPage(ctx) {
    console.log(ctx);
    console.log(ctx.params);

    const moto = await getMotoById(ctx.params.id);
    console.log(moto);

    const userData = getUserData();
    const isOwner = userData && moto._ownerId == userData.id;

    console.log(userData);
    console.log(moto);
    console.log(isOwner);


    ctx.render(detailsTemplate(moto, isOwner, onDelete));


    async function onDelete() {
        const choice = confirm(`Are you sure you want to delete this ${moto.model} FOREVER?`);
        if (choice) {
            await deleteById(ctx.params.id)
            ctx.page.redirect('/motors');
        }
    }
}