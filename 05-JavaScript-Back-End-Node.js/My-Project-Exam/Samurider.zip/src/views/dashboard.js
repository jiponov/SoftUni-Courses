import { html } from '../lib.js';
import { getAllMotors } from '../api/data.js';


const dashboardTemplate = (motors) => html`
<h2>Available Motorcycles</h2>
<section id="dashboard">
    ${motors.length == 0
    ? html`<h2 class="no-avaliable">No avaliable motorcycles yet.</h2>`
    : motors.map(motoCard)}
</section>`;


const motoCard = (moto) => html`
<div class="motorcycle">
    <img src="${moto.imageUrl}" alt="example1" />
    <h3 class="model">${moto.model}</h3>
    <p class="year">Year: ${moto.year}</p>
    <p class="mileage">Mileage: ${moto.mileage}</p>
    <p class="contact">Contact Number: ${moto.contact}</p>
    <a class="details-btn" href="/details/${moto._id}">More Info</a>
</div>`;


export async function dashboardPage(ctx) {
    const motors = await getAllMotors();
    console.log(motors);

    ctx.render(dashboardTemplate(motors));
}