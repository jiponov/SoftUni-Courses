import { html } from '../lib.js';
import { getMotoById, editMotoById } from '../api/data.js';


const editTemplate = (moto, onSubmit) => html`
<section id="edit">
    <h2>Edit Motorcycle</h2>
    <div class="form">
        <h2>Edit Motorcycle</h2>
        <form @submit=${onSubmit} class="edit-form">
            <input type="text" name="model" id="model" placeholder="Model" .value=${moto.model} />
            <input type="text" name="imageUrl" id="moto-image" placeholder="Moto Image" .value=${moto.imageUrl} />
            <input type="number" name="year" id="year" placeholder="Year" .value=${moto.year} />
            <input type="number" name="mileage" id="mileage" placeholder="mileage" .value=${moto.mileage} />
            <input type="number" name="contact" id="contact" placeholder="contact" .value=${moto.contact} />
            <textarea id="about" name="about" placeholder="about" rows="10" cols="50" .value=${moto.about}></textarea>
            <button type="submit">Edit Motorcycle</button>
        </form>
    </div>
</section>`;


export async function editPage(ctx) {
    // ---1---
    console.log(ctx.params);
    const moto = await getMotoById(ctx.params.id);

    ctx.render(editTemplate(moto, onSubmit));


    // ---2---
    async function onSubmit(event) {
        event.preventDefault();
        const formData = new FormData(event.target);

        const model = formData.get('model').trim();
        const imageUrl = formData.get('imageUrl').trim();
        const year = formData.get('year').trim();
        const mileage = formData.get('mileage').trim();
        const contact = formData.get('contact').trim();
        const about = formData.get('about').trim();

        if (model == '' || imageUrl == '' || year == '' || mileage == '' || contact == '' || about == '') {
            return alert('All fields are required!!!!');
        }

        await editMotoById(ctx.params.id, {
            model,
            imageUrl,
            year,
            mileage,
            contact,
            about
        });

        ctx.page.redirect('/details/' + ctx.params.id);
    }
}