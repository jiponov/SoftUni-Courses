import * as api from './api.js';


export const login = api.login;
export const register = api.register;
export const logout = api.logout;


export async function getAllMotors() {
    return api.get('/data/motorcycles?sortBy=_createdOn%20desc');
}

export async function createMoto(moto) {
    return api.post('/data/motorcycles', moto);
}

export async function getMotoById(id) {
    return api.get('/data/motorcycles/' + id);
}

export async function deleteById(id) {
    return api.del('/data/motorcycles/' + id);
}

export async function editMotoById(id, moto) {
    return api.put('/data/motorcycles/' + id, moto);
}